#include <vector>
#include <string>

#include "FastaSeq.h"
#include "Contig.h"


Contig::Contig(){}
Contig::~Contig(){}

//int Contig::compareTo(Contig ctg){}  // not done!!
